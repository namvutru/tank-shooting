import os
from random import randint
import pygame,sys

from pygame.constants import QUIT

pygame.init()
WIDTH, HEIGHT = 800, 600
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("namlt")



#Load image
TANK_RED = pygame.image.load(os.path.join("images", "tank_red.png"))
TANK_DARK = pygame.image.load(os.path.join("images", "tank_dark.png"))
TANK_GREEN = pygame.image.load(os.path.join("images", "tank_green.png"))
TANK_SAND = pygame.image.load(os.path.join("images", "tank_sand.png"))

#Player tank
TANK_BLUE = pygame.image.load(os.path.join("images", "tank_blue.png"))
#Bullets
RED_BULLET = pygame.image.load(os.path.join("images", "bulletred2.png"))
DARK_BULLET = pygame.image.load(os.path.join("images", "bulletdark2.png"))
GREEN_BULLET = pygame.image.load(os.path.join("images", "bulletgreen2.png"))
SAND_BULLET = pygame.image.load(os.path.join("images", "bulletsand2.png"))
BLUE_BULLET = pygame.image.load(os.path.join("images", "bulletblue2.png"))

WALL= pygame.image.load(os.path.join("images","wall.png"))

BG = pygame.image.load(os.path.join("images", "grass.png"))

listwall=[]
listbullet=[]

class Tank:
	def __init__(self, x, y,direction) :
		self.x=x
		self.y=y
		self.tank_img = TANK_BLUE			
		self.direction=direction

	def draw(self):
		
		if (self.direction == "right"):
			self.tank_img = pygame.transform.rotate(TANK_BLUE, -90)
		elif (self.direction == "left"):
			self.tank_img = pygame.transform.rotate(TANK_BLUE, 90)
		elif (self.direction == "up"):
			self.tank_img = pygame.transform.rotate(TANK_BLUE, 0)
		elif (self.direction == "down"):
			self.tank_img = pygame.transform.rotate(TANK_BLUE, 180)

		WIN.blit(self.tank_img,(self.x,self.y))
	def shoot(self):
		newbullet= Bullet(self.x,self.y,self.direction)
		listbullet.append(newbullet)

	def get_width(self):
		return self.tank_img.get_width()

	def get_height(self):
		return self.tank_img.get_height()
	
class Bullet:
	def __init__(self, x, y,direction):
		self.x = x
		self.y = y
		self.img = RED_BULLET
		self.direction=direction

	def draw(self):
		if (self.direction == "right"):
			self.img = pygame.transform.rotate(self.img, 0)
		elif (self.direction == "left"):
			self.img = pygame.transform.rotate(self.img, -180)
		elif (self.direction == "up"):
			self.img = pygame.transform.rotate(self.img, -90)
		elif (self.direction == "down"):
			self.img= pygame.transform.rotate(self.img, -90)
		WIN.blit(self.img, (self.x, self.y))

	def move(self,vel):
		if self.direction == "up":
			self.y -= vel
		elif self.direction == "down":
			self.y += vel
		elif self.direction == "right":
			self.x += vel
		elif self.direction == "left":
			self.x -= vel

def drawbullet():
	for i in listbullet:
		i.move(3)
		i.draw()

class Wall:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.img=WALL
        self.size=50 

    def draw(self):
            WIN.blit(self.img,(self.x,self.y))

def createwall():
        for  i in range(16):
            for j in range(1,11):
                s= randint(0,2) 
                if s==1:
                    listwall.append(Wall(i*50,j*50))

def createmap():
     for i in listwall:
         i.draw()
          


def main():
	createwall() 
	run = True
	player = Tank(400, 550,"up")
	clock = pygame.time.Clock()
	FPS=60
	lost = False
	lost_count = 0
	player_vel=3
	def redraw_window():
	
		WIN.blit(BG, (0,0))	#draw text
		createmap() 
		player.draw()
		drawbullet()
		pygame.display.update()

	while run:
		clock.tick(FPS)
		redraw_window()

		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				run = False	

		keys = pygame.key.get_pressed()
		if keys[pygame.K_LEFT] and player.x - player_vel > 0 :
			player.direction="left"
			player.x -= player_vel
		elif keys[pygame.K_RIGHT] and player.x + player_vel + player.get_width() < WIDTH :
			player.direction="right"
			player.x += player_vel
		elif keys[pygame.K_UP] and player.y - player_vel > 0 :
			player.direction="up"
			player.y -= player_vel
		elif keys[pygame.K_DOWN] and player.y + player_vel + player.get_height() < HEIGHT :
			player.direction="down"
			player.y += player_vel
		elif keys[pygame.K_SPACE]:
			player.shoot()
main()